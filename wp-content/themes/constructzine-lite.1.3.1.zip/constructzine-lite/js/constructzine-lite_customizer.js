jQuery(document).ready(function() {

	jQuery('.wp-full-overlay-sidebar-content').prepend('<a style="margin-top: 5px;margin-bottom: 5px; margin-left: 93px;"href="https://themeisle.com/documentation-constructzine-lite" class="button" target="_blank">Documentation</a>');
    jQuery('.wp-full-overlay-sidebar-content').prepend('<a style="margin-top: 5px;margin-bottom: 5px; margin-left: 87px;"href="https://themeisle.com/themes/constructzine-construction-wordpress-theme/" class="button" target="_blank">View PRO version</a>');

});