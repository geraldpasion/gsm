

### 1.3.1 - 26/02/2015

 Changes: 


 * This fixed #40
 * fixed overlapping chid and line in menu
 * Merge pull request #44 from rodica-andronache/development

menu issue #40
 * Fixed #46, fatal error in Customizer
 * Update style.css


### 1.2.8 - 03/01/2015

 Changes: 


 * added comments back on pages
 * increased vers


### 1.2.7 - 29/12/2014

 Changes: 


 * Update style.css


### 1.2.7 - 29/12/2014

 Changes: 


 * -translatable text in footer; -customizer sidebar-home; -add large Pro button; -add css to title; -remove text from search widget; -remove comments on pages
 * this fixes #25
 * this fixes #25
 * this fixes #22
 * this fixes #28
 * this fixes #27
 * this fixes #31
 * this fixes #30
 * Merge pull request #29 from cristian-ungureanu/development

Changes
 * This fixes #30, full widtg template responsive + update style version
 * Changed class name for full width page
 * This fixes #23 search form
 * This fixes #20 translated text in footer
 * Changed tags+description
 * This fixes #31
 * This fixes #24 site title if no logo
 * Fixed social buttons
 * This fixes #27 translated hardcoded sidebar
 * This fixes #25
 * Larger font size for box, left align in sidebar
 * sync the homepage right widget size.


### 1.2.4 - 19/12/2014

 Changes: 


 * added forum , documentation links and sections available in pro version
 * Added on wp.org repository
 * added wp product review


### 1.2.2 - 03/12/2014

 Changes: 


 * Update style.css


### 1.2.1 - 03/12/2014

 Changes: 


 * fixed comments reply and readme typo
 * Fixed customizer sanitization and tgm plugin error
 * #2 - small font on single page

Added in style.css, a font-size for all the paragraphs in post entry
class
 * This fixes #2

Added style for all the paragraphs with the 'post-entry' class, for text
esthethics
 * This fixes #2 - new

Removed !important, added the proper attributes in the correct class
 * This fixes #3

Added valid translation-ready in all .php files
- function -> fload_theme_textdomain
- other .php files -> 'constructzine-lite' argument

Added a few tags to the template (custom-header, yellow, gray, black)
 * This fixes #4

Added a credit link bellow the map widget. The links have the 'nofollow'
property similar with other template copyright standards.
 * Merge pull request #5 from DragosBubu/development

Development
 * Fixed some translations domains, css style for single page and footer link, fixed footer link, added more tags
 * Update style.css


### 1.1 - 17/10/2014

 Changes: 


 * First version
 * improved images and changed encoding
 * Fixed wordpress.org 20326 ticket
 * Remove archive from theme folder
