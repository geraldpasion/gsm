Reception Theme by HermesThemes.com

Theme Details: 
http://www.hermesthemes.com/themes/reception/

Theme Demo:
http://demo.hermesthemes.com/reception/


BUNDLED THIRD-PARTY SCRIPTS
---------------

/*
Superfish - http://users.tpg.com.au/j_birch/plugins/superfish/
License: Distributed under the MIT and GPL licenses
Copyright: Joel Birch
*/

/*
FlexSlider - ?http://www.woothemes.com/flexslider/
License: Distributed under the terms of the GPL
Copyright: WooThemes, WooThemes.com
*/

The 4 photos visible in screenshot.png were all taken by the developer of the theme (Dumitru Brinzan) and doesn't violate any copyright.
The contents of screenshot.png are released under the same license as the theme.


THEME DOCUMENTATION
---------------

Certain parts of the theme can be changed directly from the Appearance > Customize page.
Open General Settings and Homepage Settings tabs on the Customize screen and set up the options that are presented.

QUICK SPECS
---------------

1. The theme's total width is 1140px.
2. The main content width is 710px.
3. The sidebar width is 340px.
4. Featured Images are of 3 custom sizes:
	- 1080x450 for the slideshow;
	- 340x220 for the featured pages on the homepage;
	- 200x200 for the archive pages.


THEME CHANGELOG
---------------

Version 1.1.4 - 24 April, 2015
	- Corrections and fixes for WordPress.org theme check compatibility.

Version 1.1.3 - 21 April, 2015
	- Corrections and fixes for WordPress.org theme check compatibility.

Version 1.1.2 - 20 April, 2015
	- Corrections and fixes for WordPress.org theme check compatibility.

Version 1.1 - 16 April, 2015
	- Corrections and fixes for WordPress.org theme check compatibility.

Version 1.0 - 27 March, 2015
	
	- Initial release