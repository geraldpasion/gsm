<?php
/**
 * Email Body
 *
 * 
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Do not remove the {email} tag.

?>
{email}
