
<div class="row">
  <div class="span12">
	  <div class="well">
	  	<div class="row">
	  		<div class="span6">
	  			<h3>Love the Twitter Bootstrap plugin?</h3>
				<p>Please help <u>spread the word</u> or check out what else we do ...</p>
	  		</div>
	  		<div class="span4">
				<a href="https://twitter.com/share" class="twitter-share-button" data-url="http://icwp.io/r" data-text="I use the #WordPress Twitter Bootstrap plugin to make my site look awesome the easy way!" data-via="iControlWP" data-size="large">Tweet</a><script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
	  		</div>
	  	</div>
		<div class="row">
			<div class="span6">
				<ul>
					<li><a href="http://icwp.io/4" target="_blank"><strong>Manage <u>All</u> Your WordPress Sites In 1 Place!</strong></a></li>
					<li><a href="http://icwp.io/y" target="_blank">Check out all our other WordPress Plugins</a></li>
				</ul>
			</div>
			<div class="span5">
				<ul>
					<li><a href="http://icwp.io/a" target="_blank"><strong>Visit the plugin Help & Support page</strong></a>.</li>
					<li><a href="http://wordpress.org/extend/plugins/wordpress-bootstrap-css/" target="_blank">Show some love, and give this a 5 star rating on WordPress.org.</a></li>
				</ul>
			</div>
		</div>
	  </div><!-- / well -->
  </div><!-- / span12 -->
</div><!-- / row -->
